from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
import os
import numpy as np
from PIL import Image
import json
from datetime import datetime
import uuid

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create upload directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Disease information and treatment recommendations
DISEASE_INFO = {
    'Salmonella': {
        'name': 'Salmonella',
        'severity': 'High',
        'description': 'Bacterial infection that affects the digestive system of poultry.',
        'symptoms': ['Diarrhea', 'Lethargy', 'Reduced appetite', 'Dehydration', 'Ruffled feathers'],
        'treatment': [
            'Isolate affected birds immediately',
            'Administer antibiotics as prescribed by veterinarian',
            'Provide electrolyte solutions',
            'Maintain proper hygiene and sanitation',
            'Monitor flock closely for 2-3 weeks'
        ],
        'prevention': [
            'Maintain clean water sources',
            'Proper feed storage',
            'Regular cleaning of coops',
            'Vaccination programs',
            'Quarantine new birds'
        ]
    },
    'New Castle Disease': {
        'name': 'New Castle Disease',
        'severity': 'Critical',
        'description': 'Highly contagious viral disease affecting respiratory, nervous, and digestive systems.',
        'symptoms': ['Respiratory distress', 'Neurological signs', 'Reduced egg production', 'Diarrhea', 'Swollen head'],
        'treatment': [
            'No specific treatment available',
            'Supportive care and symptomatic treatment',
            'Quarantine affected birds',
            'Report to veterinary authorities immediately',
            'Implement strict biosecurity measures'
        ],
        'prevention': [
            'Vaccination (most important)',
            'Strict biosecurity protocols',
            'Limit visitor access',
            'Proper disinfection procedures',
            'Monitor flock health regularly'
        ]
    },
    'Coccidiosis': {
        'name': 'Coccidiosis',
        'severity': 'Moderate',
        'description': 'Parasitic disease affecting the intestinal tract of poultry.',
        'symptoms': ['Bloody diarrhea', 'Weight loss', 'Decreased feed consumption', 'Dehydration', 'Pale combs'],
        'treatment': [
            'Administer anticoccidial medications',
            'Improve ventilation and reduce moisture',
            'Provide clean, dry bedding',
            'Ensure adequate nutrition',
            'Separate affected birds if necessary'
        ],
        'prevention': [
            'Use anticoccidial drugs in feed',
            'Maintain dry litter conditions',
            'Proper stocking density',
            'Regular cleaning of feeders and waterers',
            'Gradual exposure to build immunity'
        ]
    },
    'Healthy': {
        'name': 'Healthy Bird',
        'severity': 'None',
        'description': 'No signs of disease detected. The bird appears healthy.',
        'symptoms': ['Active behavior', 'Good appetite', 'Normal egg production', 'Bright eyes', 'Clean feathers'],
        'treatment': [
            'Continue current management practices',
            'Maintain regular health monitoring',
            'Ensure proper nutrition',
            'Keep vaccination schedule up to date'
        ],
        'prevention': [
            'Maintain biosecurity protocols',
            'Regular health checks',
            'Proper nutrition program',
            'Clean water supply',
            'Stress management'
        ]
    }
}

# Mock prediction function (replace with actual ML model)
def predict_disease(image_path):
    """
    Mock prediction function. In a real implementation, this would load
    your trained model and make actual predictions.
    """
    # For demonstration, we'll randomly predict based on image name or use a simple rule
    import random
    diseases = ['Salmonella', 'New Castle Disease', 'Coccidiosis', 'Healthy']
    
    # Generate a mock prediction with confidence scores
    prediction = random.choice(diseases)
    confidence = random.uniform(0.75, 0.95)
    
    return {
        'prediction': prediction,
        'confidence': confidence,
        'probabilities': {
            'Salmonella': random.uniform(0.1, 0.9),
            'New Castle Disease': random.uniform(0.1, 0.9),
            'Coccidiosis': random.uniform(0.1, 0.9),
            'Healthy': random.uniform(0.1, 0.9)
        }
    }

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            # Generate unique filename
            filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Make prediction
            result = predict_disease(filepath)
            
            # Get disease information
            disease_info = DISEASE_INFO.get(result['prediction'], {})
            
            return render_template('result.html', 
                                 prediction=result, 
                                 disease_info=disease_info,
                                 image_path=filename)
        else:
            flash('Invalid file type. Please upload PNG, JPG, JPEG, or GIF images.')
    
    return render_template('upload.html')

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """API endpoint for programmatic predictions"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if file and allowed_file(file.filename):
        filename = str(uuid.uuid4()) + '.' + file.filename.rsplit('.', 1)[1].lower()
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        result = predict_disease(filepath)
        disease_info = DISEASE_INFO.get(result['prediction'], {})
        
        return jsonify({
            'prediction': result['prediction'],
            'confidence': result['confidence'],
            'probabilities': result['probabilities'],
            'disease_info': disease_info,
            'timestamp': datetime.now().isoformat()
        })
    
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/diseases')
def diseases():
    return render_template('diseases.html', diseases=DISEASE_INFO)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)